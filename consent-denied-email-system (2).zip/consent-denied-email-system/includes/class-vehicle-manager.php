<?php
if (!defined('ABSPATH')) {
    exit;
}

class CD_Vehicle_Manager {
    private $wpdb;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    public function get_user_vehicles($user_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}cd_vehicles 
            WHERE user_id = %d AND active = 1 
            ORDER BY date_added DESC",
            $user_id
        ));
    }
    
    public function add_vehicle($user_id, $data) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'cd_vehicles',
            array(
                'user_id' => $user_id,
                'registration_number' => strtoupper(sanitize_text_field($data['registration_number'])),
                'make' => sanitize_text_field($data['make']),
                'model' => sanitize_text_field($data['model']),
                'color' => sanitize_text_field($data['color']),
                'active' => 1
            ),
            array('%d', '%s', '%s', '%s', '%s', '%d')
        );
    }
    
    public function delete_vehicle($vehicle_id, $user_id) {
        return $this->wpdb->update(
            $this->wpdb->prefix . 'cd_vehicles',
            array('active' => 0),
            array('id' => $vehicle_id, 'user_id' => $user_id),
            array('%d'),
            array('%d', '%d')
        );
    }
    
    public function get_vehicle_count($user_id) {
        return $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->wpdb->prefix}cd_vehicles 
            WHERE user_id = %d AND active = 1",
            $user_id
        ));
    }
    
    public function is_premium_subscriber($user_id) {
        // Since WooCommerce Subscriptions is deactivated, check for orders instead
        global $wpdb;
        $premium_subscription_id = get_option('cd_premium_subscription_id', '847');
        
        // Look for completed or processing orders containing the premium (Enhanced) product
        $has_premium = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
            FROM {$wpdb->prefix}woocommerce_order_items oi
            JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id AND oim.meta_key = '_product_id'
            JOIN {$wpdb->posts} o ON oi.order_id = o.ID
            WHERE o.post_type = 'shop_order'
            AND o.post_status IN ('wc-completed', 'wc-processing')
            AND oim.meta_value = %d
            AND o.post_author = %d",
            $premium_subscription_id,
            $user_id
        ));
        
        return $has_premium > 0;
    }
    
    public function is_basic_subscriber($user_id) {
        // Since WooCommerce Subscriptions is deactivated, check for orders instead
        global $wpdb;
        $basic_subscription_id = get_option('cd_basic_subscription_id', '846');
        
        // Look for completed or processing orders containing the basic (Core) product
        $has_basic = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
            FROM {$wpdb->prefix}woocommerce_order_items oi
            JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id AND oim.meta_key = '_product_id'
            JOIN {$wpdb->posts} o ON oi.order_id = o.ID
            WHERE o.post_type = 'shop_order'
            AND o.post_status IN ('wc-completed', 'wc-processing')
            AND oim.meta_value = %d
            AND o.post_author = %d",
            $basic_subscription_id,
            $user_id
        ));
        
        return $has_basic > 0;
    }
    
    public function can_add_more_vehicles($user_id) {
        $count = $this->get_vehicle_count($user_id);
        
        // Enhanced (Premium) subscribers get unlimited vehicles
        if ($this->is_premium_subscriber($user_id)) {
            return true;
        }
        
        // Core (Basic) subscribers get one vehicle
        if ($this->is_basic_subscriber($user_id)) {
            return $count < 1;
        }
        
        // No subscription = no vehicles
        return false;
    }

    public function get_subscription_status($user_id) {
        if ($this->is_premium_subscriber($user_id)) {
            return 'premium';
        }
        if ($this->is_basic_subscriber($user_id)) {
            return 'basic';
        }
        return 'none';
    }
}